Author: Bryan Grant
Date: 6/6/2018

Description:
This project is for Assignment 1 of the Introduction to Embedded Systems Software and Development Environments by the University of Colorado Boulder and taught by Prof. Alex Fosdick.

This project is a simple application that performs statistical analytics on a dataset and reports the following:  the maximum, minimum, mean, and median. Additionally, this project will sort the data from largest to smallest and print the results nicely to the screen.

Through this project we will also become familiar with using git repositories and virtual machines.
